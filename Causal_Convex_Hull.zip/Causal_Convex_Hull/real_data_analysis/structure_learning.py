import pandas as pd
import random
import numpy as np
import networkx as nx
from pgmpy.models import BayesianNetwork
from pgmpy.estimators import MaximumLikelihoodEstimator, HillClimbSearch
from pgmpy.readwrite import BIFWriter
from pgmpy.estimators import BicScore
import warnings

warnings.filterwarnings('ignore')

############################################### Data Loading ####################################################
data = pd.read_csv("E:/snn(yan)/Causal_Convex_Hull/real_data_analysis/Mushroom_preprocessed.csv")

###################################### Structure Learning ###################################################
random.seed(72)
np.random.seed(72)

score = BicScore(data)
estimator = HillClimbSearch(data)


G = estimator.estimate(
    scoring_method=score,
    max_indegree=None,
    max_iter=int(1e4),
    fixed_edges=[]
)

edges = G.edges()



#########################################  Model Training and Saving #############################################
model = BayesianNetwork(edges)

# Check if the graph is a Directed Acyclic Graph (DAG)
# Critical validation: Bayesian Networks strictly require DAG structure
print("\n" + "="*60)
is_dag = nx.is_directed_acyclic_graph(model)
if is_dag:
    print("The graph is a Directed Acyclic Graph (DAG)")
else:
    print("The graph is NOT a Directed Acyclic Graph (DAG)")

# Train Conditional Probability Distributions (CPTs)
# Using Maximum Likelihood Estimation (MLE) for parameter learning
print("\nTraining Conditional Probability Distributions (CPTs)...")
model.fit(data, estimator=MaximumLikelihoodEstimator)

# Save the trained Bayesian Network model
# Export to BIF (Bayesian Interchange Format) for cross-tool compatibility
BIFWriter(model).write_bif("E:/snn(yan)/Causal_Convex_Hull/real_data_analysis/Mushroom_model.bif")
print("\nModel saved successfully")


