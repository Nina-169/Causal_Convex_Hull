import warnings
import sys
import os

warnings.filterwarnings("ignore")
warnings.simplefilter("ignore")
sys.stderr = open(os.devnull, 'w')

from pgmpy.readwrite import BIFReader
from core_algorithms import TSCCHC
from time_calculation import calculate_average_wall_clock_time
from causal_estimation import compute_average_est_ATE_realdata
from causal_estimation import compute_ATE_from_data
from baseline_methods_guo2023 import reduce_subgraph
import pandas as pd



# Load a Bayesian network model
reader = BIFReader('E:/snn(yan)/Causal_Convex_Hull/real_data_analysis/Mushroom_model.bif')
G = reader.get_model()

#Set parameters
treatment = "odor"
outcome = "is_poisonous"

# State mapping
treatment_pos_idx = 1
treatment_neg_idx = 0
outcome_pos_idx = 1

# Load the dataset
data = pd.read_csv("E:/snn(yan)/Causal_Convex_Hull/real_data_analysis/Mushroom_preprocessed.csv", header=0)



G_H, H = TSCCHC(G, treatment, outcome)
subdata_H = data[list(H)].copy()

G_1, reduce_subgraph_nodes = reduce_subgraph(G, treatment, outcome)
subdata_G1 = data[list(reduce_subgraph_nodes)].copy()
print(f"\nCompression Performance Comparison:")
print(f"Original graph G: {G.number_of_nodes()} nodes, {G.number_of_edges()} edges")
print(f"Convex subgraph G_H: {G_H.number_of_nodes()} nodes, {G_H.number_of_edges()} edges (NCR: {(1-G_H.number_of_nodes()/G.number_of_nodes())*100:.1f}%)")
print(f"Baseline method G_1: {G_1.number_of_nodes()} nodes, {G_1.number_of_edges()} edges (NCR: {(1-G_1.number_of_nodes()/G.number_of_nodes())*100:.1f}%)")


print("\n" + "="*50)
print("ATE Estimation and Bootstrap Analysis (B=500)")
print("="*50)

B = 500

print("\n Computing Model I (Original graph)...")
result1 = compute_average_est_ATE_realdata(
    data, G, treatment, outcome,
    treatment_pos_idx, treatment_neg_idx, outcome_pos_idx,
    B=B,seed=42)

print("Computing Model II...")
result2 = compute_average_est_ATE_realdata(
    subdata_H, G_H, treatment, outcome,
    treatment_pos_idx, treatment_neg_idx, outcome_pos_idx,
    B=B,seed=42)


print("Computing Model III (Baseline method)...")
result3 = compute_average_est_ATE_realdata(
    subdata_G1, G_1, treatment, outcome,
    treatment_pos_idx, treatment_neg_idx, outcome_pos_idx,
    B=B,seed=42)


print("\n" + "="*70)
print("ATE Estimation Results (Point Estimates Based on Complete Data)")
print("="*70)
print(f"{'Model':<15} {'ATE Point Est.':<12} {'Bootstrap Mean':<12} {'Bootstrap SE':<12} {'95% CI':<25}")
print("-"*70)

results = [
    ("I (Original graph)", result1),
    ("II (Convex subgraph)", result2),
    ("III (Baseline)", result3)
]

for name, res in results:
    print(f"{name:<15} {res['ATE_full']:.4f}       {res['ATE_boot_mean']:.4f}       "
          f"{res['ATE_boot_std']:.4f}       [{res['ATE_boot_CI_lower']:.4f}, {res['ATE_boot_CI_upper']:.4f}]")

print("="*70)

print("\n" + "="*50)
print("Computational Time Analysis")
print("="*50)


# Compression time
G_H_compress_time = calculate_average_wall_clock_time(
    TSCCHC, (G, treatment, outcome), num_runs=100, warmup=2)

G_1_compress_time = calculate_average_wall_clock_time(
    reduce_subgraph, (G, treatment, outcome), num_runs=100, warmup=2)

# Estimation time
original_estimate_time = calculate_average_wall_clock_time(
    compute_ATE_from_data,
    (data, G, treatment, outcome, treatment_pos_idx, treatment_neg_idx, outcome_pos_idx),
    num_runs=100, warmup=2)


G_H_estimate_time = calculate_average_wall_clock_time(
    compute_ATE_from_data,
    (subdata_H, G_H, treatment, outcome, treatment_pos_idx, treatment_neg_idx, outcome_pos_idx),
    num_runs=100, warmup=2)


G_1_estimate_time = calculate_average_wall_clock_time(
    compute_ATE_from_data,
    (subdata_G1, G_1, treatment, outcome, treatment_pos_idx, treatment_neg_idx, outcome_pos_idx),
    num_runs=100, warmup=2)

# Total time
G_total_time = original_estimate_time
G_H_total_time = G_H_compress_time + G_H_estimate_time
G_1_total_time = G_1_compress_time + G_1_estimate_time

# 打印时间结果
print("\n" + "="*60)
print("Computational Time Comparison (seconds)")
print("="*60)
print(f"{'Model':<15} {'Compression':<12} {'Estimation':<12} {'Total':<12} {'Speedup':<12}")
print("-"*60)

print(f"{'I (Original graph)':<15} {'—':<12} {original_estimate_time:.4f}     {G_total_time:.4f}     {'—':<12}")
print(f"{'II (Convex subgraph)':<15} {G_H_compress_time:.4f}     {G_H_estimate_time:.4f}     {G_H_total_time:.4f}     {(1-G_H_total_time/G_total_time)*100:.1f}%")
print(f"{'III (Baseline)':<15} {G_1_compress_time:.4f}     {G_1_estimate_time:.4f}     {G_1_total_time:.4f}     {(1-G_1_total_time/G_total_time)*100:.1f}%")
print("="*60)
