import warnings
import sys
import os

warnings.filterwarnings("ignore")
warnings.simplefilter("ignore")
sys.stderr = open(os.devnull, 'w')

from pgmpy.readwrite import BIFReader
from core_algorithms import TSCCHC
from time_calculation import calculate_average_wall_clock_time
from causal_estimation import compute_true_ATE
from causal_estimation import compute_average_est_ATE_statistics
from baseline_methods_guo2023 import reduce_subgraph



# Load a Bayesian network model
reader = BIFReader('E:/snn(yan)/BN/hepar2.bif')
G = reader.get_model()

#Set parameters
treatment = "Hyperbilirubinemia"
outcome = "skin"
# State mapping ：['present', 'absent'] → [0, 1]
treatment_pos_idx = 0
treatment_neg_idx = 1
outcome_pos_idx = 0

n=100  #n∈{100,1000,10000,50000,100000}
m=200   #Number of independent repeated trials,  m∈{200,100,50,30,10}

G_H,H = TSCCHC(G, treatment, outcome)
G_1,reduce_subgraph_nodes = reduce_subgraph(G,treatment,outcome)
print("convex subgraph nodes:", H)
print("G_1_nodes:",reduce_subgraph_nodes)

print(f"Number of nodes in original graph G: {G.number_of_nodes()}")
print(f"Number of edges in original graph G: {G.number_of_edges()}")
print(f"Number of nodes in convex subgraph G_H: {G_H.number_of_nodes()}")
print(f"Number of edges in convex subgraph G_H: {G_H.number_of_edges()}")
print(f"Number of nodes in G_1: {G_1.number_of_nodes()}")
print(f"Number of edges in G_1: {G_1.number_of_edges()}")

#ATE
true_ATE, true_psi1, true_psi0 = compute_true_ATE(
        G, treatment, outcome,treatment_pos_idx, treatment_neg_idx, outcome_pos_idx)
result1 = compute_average_est_ATE_statistics(G, treatment, outcome, treatment_pos_idx, treatment_neg_idx, outcome_pos_idx,
                                       n, m,true_ATE=true_ATE)
result2 = compute_average_est_ATE_statistics(G, treatment, outcome, treatment_pos_idx, treatment_neg_idx, outcome_pos_idx,
                                       n, m,true_ATE=true_ATE, G_R=G_H, R=H)
result3 = compute_average_est_ATE_statistics(G, treatment, outcome, treatment_pos_idx, treatment_neg_idx, outcome_pos_idx,
                                       n, m,true_ATE=true_ATE, G_R=G_1, R=reduce_subgraph_nodes)

print("\n" + "=" * 50)
print("Original graph results")
print("=" * 50)
for key, value in result1.items():
    if isinstance(value, float):
        print(f"{key}: {value:.4f}")
    else:
        print(f"{key}: {value}")
print("=" * 50)

print("\n" + "=" * 50)
print("Algorithm 3 results")
print("=" * 50)
for key, value in result2.items():
    if isinstance(value, float):
        print(f"{key}: {value:.4f}")
    else:
        print(f"{key}: {value}")
print("=" * 50)

print("\n" + "=" * 50)
print("Results from Guo et al.")
print("=" * 50)
for key, value in result3.items():
    if isinstance(value, float):
        print(f"{key}: {value:.4f}")
    else:
        print(f"{key}: {value}")
print("=" * 50)


original_estimate_time =calculate_average_wall_clock_time(compute_average_est_ATE_statistics,(G, treatment, outcome, treatment_pos_idx, treatment_neg_idx, outcome_pos_idx,
                                       n, 1, true_ATE), num_runs=100, warmup=2)
print(f"Estimation time for the original network: {original_estimate_time :.4f} s")

G_H_compress_time =calculate_average_wall_clock_time(TSCCHC,(G, treatment, outcome), num_runs=100, warmup=2)
G_H_estimate_time =calculate_average_wall_clock_time(compute_average_est_ATE_statistics, (G, treatment, outcome, treatment_pos_idx, treatment_neg_idx, outcome_pos_idx,
                                       n, 1, true_ATE, G_H, H), num_runs=100, warmup=2)
G_H_total_time = G_H_compress_time + G_H_estimate_time
print(f"Total time for G_H: {G_H_total_time:.4f} s")

G_1_compress_time =calculate_average_wall_clock_time(reduce_subgraph,(G, treatment, outcome),num_runs=100, warmup=2)
G_1_estimate_time =calculate_average_wall_clock_time(compute_average_est_ATE_statistics,(G, treatment, outcome, treatment_pos_idx, treatment_neg_idx, outcome_pos_idx,
                                       n, 1, true_ATE, G_1, reduce_subgraph_nodes), num_runs=100, warmup=2)
G_1_total_time = G_1_compress_time + G_1_estimate_time
print(f"Total time for G_1: {G_1_total_time:.4f} s")



