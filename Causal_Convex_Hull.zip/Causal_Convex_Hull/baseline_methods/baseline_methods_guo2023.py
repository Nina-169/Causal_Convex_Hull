import networkx as nx
import itertools

# Check d-separation
def check_d_separation(g, x, y, z):
    # Convert input to sets (handling single nodes or node lists)
    x_set = {x} if isinstance(x, str) else set(x)
    y_set = {y} if isinstance(y, str) else set(y)
    z_set = {z} if isinstance(z, str) else set(z)

    # Exclude nodes already in z from x and y
    x_set -= z_set
    y_set -= z_set

    # Use is_d_separator instead of d_separated
    return nx.is_d_separator(g, x_set, y_set, z_set)

# Convert DAG object to adjacency matrix and vice versa
def dag_to_adj_mat(g):
    v = list(nx.topological_sort(g))
    n = len(v)
    amat = [[0] * n for _ in range(n)]
    edges = list(g.edges())
    if len(edges) > 0:
        node_to_index = {node: index for index, node in enumerate(v)}
        for x, y in edges:
            amat[node_to_index[x]][node_to_index[y]] = 1
    return amat

# Convert adjacency matrix back to directed graph
def adjacency_matrix_to_dag(adj_matrix, nodes):
    g = nx.DiGraph()
    n = len(nodes)
    for i, node1 in enumerate(nodes):
        for j, node2 in enumerate(nodes):
            if i < n and j < n and adj_matrix[i][j] == 1:
                g.add_edge(node1, node2)
    return g

# Latent projection
def project_out(g, v_i):
    v = list(nx.topological_sort(g))
    adj_mat = dag_to_adj_mat(g)
    pa = list(g.predecessors(v_i))
    ch = list(g.successors(v_i))
    assert len(ch) < 2
    if len(ch) == 1 and len(pa) > 0:
        for p in pa:
            adj_mat[v.index(p)][v.index(ch[0])] = 1
    sub_v = [node for node in v if node != v_i]
    new_adj_mat = [[adj_mat[i][j] for j in range(len(adj_mat[i])) if v[j] in sub_v]
                   for i in range(len(adj_mat)) if v[i] in sub_v]
    new_g = adjacency_matrix_to_dag(new_adj_mat, sub_v)
    return new_g

# Both indirect ancestors and instrumental variables
def find_indirect_ancestors(g, treatment, outcome):
    # 1. Get common ancestors (including A and Y themselves)
    ancestors_treatment = nx.ancestors(g, treatment).union({treatment})
    ancestors_outcome = nx.ancestors(g, outcome).union({outcome})
    i = ancestors_treatment.intersection(ancestors_outcome)

    # Remove treatment variable itself
    i.discard(treatment)

    # Filter real instrumental variables
    def is_valid_instrument(u):
        paths = list(nx.all_simple_paths(g, source=u, target=outcome))
        for path in paths:
            # Check if path passes through treatment variable
            if treatment in path:
                continue
            # Check if path is open
            open_path = True
            for j in range(len(path) - 1):
                if (path[j], path[j + 1]) not in g.edges():
                    open_path = False
                    break
            if open_path:
                return False
        return True

    valid_instruments = {u for u in i if is_valid_instrument(u)}
    g = g.subgraph(valid_instruments)
    return list(nx.topological_sort(g))

# Define non-ancestor set N
def find_non_ancestors(g, outcome):
    v = nx.topological_sort(g)
    ancestors = nx.ancestors(g, outcome) | {outcome}  # Defined as ancestors of Y including itself
    non_ancestors = [node for node in v if node not in ancestors]
    return non_ancestors

# Project out non-ancestor set and indirect ancestor set
def project_out_n_and_i(g, treatment, outcome):
    v = nx.topological_sort(g)
    n = find_non_ancestors(g, outcome)
    g = g.subgraph([v_i for v_i in v if v_i not in n])
    i = find_indirect_ancestors(g, treatment, outcome)
    max_iterations = 100  # Prevent infinite loop
    iteration = 0

    while len(i) > 0 and iteration < max_iterations:
        iteration += 1
        v_j = i[-1]

        try:
            g = project_out(g, v_j)
            i = find_indirect_ancestors(g, treatment, outcome)

        except Exception as e:
            print(f"Error projecting variable {v_j}: {str(e)}")
            break

    return g

# Define baseline covariate set W
def find_w(g, treatment, outcome):
    ancestors_outcome = nx.ancestors(g, outcome).union({outcome})
    descendants_treatment = nx.descendants(g, treatment).union({treatment})
    w = ancestors_outcome - descendants_treatment  # Candidate set
    i = find_indirect_ancestors(g, treatment, outcome)
    w = w - set(i)
    g = g.subgraph(w)
    return list(nx.topological_sort(g))

# Define mediator set M, also causal nodes cn(X,Y,G)
def find_mediators(g, treatment, outcome):
    ancestors_outcome = nx.ancestors(g, outcome).union({outcome})
    descendants_treatment = nx.descendants(g, treatment).union({treatment})
    m = ancestors_outcome.intersection(descendants_treatment)  # Candidate set
    m.discard(treatment)
    g = g.subgraph(m)
    return list(nx.topological_sort(g))

# Define parent set of a node set
def find_parent_set(G, nodes):
    parents = set()
    for node in nodes:
        parents.update(G.predecessors(node))
    return parents

# Define optimal adjustment set function
def find_o(g, treatment, outcome):
    m = find_mediators(g, treatment, outcome)
    pa_m = find_parent_set(g, m)
    o = pa_m.difference(m).difference({treatment, outcome})
    g = g.subgraph(o)
    return list(nx.topological_sort(g))

# Define minimal optimal adjustment set
def find_o_min(g, treatment, outcome):
    o = find_o(g, treatment, outcome)
    if len(o) == 0:
        return o
    min_subset = None
    for size in range(0, len(o) + 1):  # Consider from non-empty subsets
        subsets = [combination for combination in itertools.combinations(o, size)]
        for subset in subsets:
            # Check if subset is a subset of O
            if all(item in o for item in subset):
                complement = list(set(o) - set(subset))
                if check_d_separation(g, {treatment}, set(complement), set(subset)):
                    sorted_subset = sorted(subset)
                    if min_subset is None or len(sorted_subset) < len(min_subset):
                        min_subset = sorted_subset
    return min_subset

# Children nodes of a node within a specific set
def find_children(g, node, specific_set):
    ch = set(g[node].keys())
    return ch.intersection(specific_set)

# Check if a node satisfies the W-criterion
def check_w_criterion(g, w_j, treatment, outcome):
    # Ensure w is a single node
    assert isinstance(w_j, str), "w must be a single node"

    # Get O set and W set
    w = find_w(g, treatment, outcome)
    o = find_o(g, treatment, outcome)

    # Check if w_j belongs to w and not to o
    if w_j not in w:
        return False
    if w_j in o:
        return False

    # Get children of w_j in w, topologically sorted
    w_j_children = [child for child in g.successors(w_j) if child in w]
    w_j_ch = list(nx.topological_sort(g.subgraph(w_j_children)))

    if not w_j_ch:  # No children, criterion not satisfied
        return False

    # Check condition for the last child
    w_j_last_ch = w_j_ch[-1]
    parents_last_ch = list(g.predecessors(w_j_last_ch))
    z_1 = set(parents_last_ch + [w_j_last_ch]) - {w_j}

    # Check d-separation: w_j ⫫ o | z_1
    if not check_d_separation(g, {w_j}, o, z_1):
        return False

    # Check chain structure conditions
    for t in range(len(w_j_ch)):
        w_j_cur = w_j_ch[t]
        if t == 0:
            w_j_prev = w_j
        else:
            w_j_prev = w_j_ch[t - 1]

        # Get parent sets
        pa_cur = set(g.predecessors(w_j_cur))
        pa_prev = set(g.predecessors(w_j_prev))

        # Condition i: w_j_prev → w_j_cur edge exists
        cond_i = (w_j_prev in pa_cur)

        # Condition ii: pa_cur ⊆ (pa_prev ∪ {w_j_prev})
        cond_ii = pa_cur.issubset(pa_prev.union({w_j_prev}))

        # Condition iii: (pa_prev - pa_cur) ⫫ w_j | (pa_cur ∪ O)
        cond_iii = check_d_separation(g, pa_prev - pa_cur, {w_j}, pa_cur.union(o))

        # If any condition fails, return False
        if not (cond_i and cond_ii and cond_iii):
            return False

    # All conditions satisfied, return True
    return True

def check_m_criterion(g, m_i, treatment, outcome):
    # Ensure m is a single node
    assert isinstance(m_i, str), "m must be a single node string"

    # Get relevant sets
    m = find_mediators(g, treatment, outcome)
    o_min = find_o_min(g, treatment, outcome)
    s = {treatment, outcome}.union(o_min)

    # Preliminary checks
    if m_i not in m:
        raise ValueError(f"Node {m_i} is not in mediator set M")
    if m_i == outcome:
        return False

    # Get children of m_i in m and sort (topological order)
    m_i_children = [child for child in g.successors(m_i) if child in m]
    m_i_ch = list(nx.topological_sort(g.subgraph(m_i_children)))
    if not m_i_ch:
        return False

    m_i_last_ch = m_i_ch[-1]
    # Build z.1 set
    parents_last_ch = set(g.predecessors(m_i_last_ch))
    z_1 = (parents_last_ch.union({m_i_last_ch})) - {m_i}

    # Check d-separation: m and s are d-separated given z_1
    if not check_d_separation(g, {m_i}, s, z_1):
        return False

    # Traverse child chain to check conditions
    for t in range(len(m_i_ch)):
        m_i_cur = m_i_ch[t]
        if t == 0:
            m_i_prev = m_i
        else:
            m_i_prev = m_i_ch[t - 1]

        pa_cur = set(g.predecessors(m_i_cur))
        pa_prev = set(g.predecessors(m_i_prev))

        # Check three conditions
        cond_i = m_i_prev in pa_cur
        cond_ii = pa_cur.issubset(pa_prev.union({m_i_prev}))
        cond_iii = check_d_separation(g, pa_prev - pa_cur, s, pa_cur)

        if not (cond_i and cond_ii and cond_iii):
            return False

    return True

# Define uninformative variable set
def find_uninformative_variables(g, treatment, outcome):
    n = find_non_ancestors(g, outcome)
    i = find_indirect_ancestors(g, treatment, outcome)
    w = find_w(g, treatment, outcome)
    m = find_mediators(g, treatment, outcome)

    u = set(n) | set(i)

    for w_j in w:
        if check_w_criterion(g, w_j, treatment, outcome):
            u.add(w_j)
    for m_i in m:
        if check_m_criterion(g, m_i, treatment, outcome):
            u.add(m_i)
    g = g.subgraph(u)
    return list(nx.topological_sort(g))

# Final reduced graph
def reduce_dag(g, treatment, outcome):
    # Step 1: Project out N and I set variables
    g = project_out_n_and_i(g, treatment, outcome)

    # Step 2: Get uninformative variable set
    v_uninfo = find_uninformative_variables(g, treatment, outcome)

    # Step 3: Remove uninformative variables one by one and adjust edges
    for v in v_uninfo:
        if v not in g.nodes():
            continue

        V = list(g.nodes())
        pa = list(g.predecessors(v))
        ch = list(g.successors(v))

        # Ensure treatment variable is at the end of children list
        if treatment in ch:
            ch = [node for node in ch if node != treatment] + [treatment]

        # Get topological order of children
        ch_subgraph = g.subgraph(ch)
        try:
            ch_topo = list(nx.topological_sort(ch_subgraph))
        except nx.NetworkXUnfeasible:
            ch_topo = ch

        # Adjust treatment variable position
        if treatment in ch_topo:
            ch_topo = [node for node in ch_topo if node != treatment] + [treatment]

        node_indices = {node: i for i, node in enumerate(V)}
        adj_mat = [[0] * len(V) for _ in range(len(V))]
        for u, w in g.edges():
            adj_mat[node_indices[u]][node_indices[w]] = 1

        # Add parent-child edges (check for cycles)
        for p in pa:
            for c in ch_topo:
                if p in node_indices and c in node_indices:
                    # Check if cycle would form
                    if nx.has_path(g, c, p):
                        continue
                    adj_mat[node_indices[p]][node_indices[c]] = 1

        # Add edges between children (according to topological order)
        if len(ch_topo) > 1:
            topo_indices = {node: i for i, node in enumerate(ch_topo)}
            for i in range(len(ch_topo)):
                for j in range(len(ch_topo)):
                    if j > i and topo_indices[ch_topo[i]] < topo_indices[ch_topo[j]]:
                        u = ch_topo[i]
                        v_adj = ch_topo[j]
                        if u in node_indices and v_adj in node_indices:
                            adj_mat[node_indices[u]][node_indices[v_adj]] = 1

        # Rebuild graph
        new_V = [node for node in V if node != v]
        if not new_V:
            return nx.DiGraph()

        new_node_indices = {node: i for i, node in enumerate(new_V)}
        new_adj_mat = [[0] * len(new_V) for _ in range(len(new_V))]
        for u in new_V:
            for w in new_V:
                if u in node_indices and w in node_indices:
                    new_adj_mat[new_node_indices[u]][new_node_indices[w]] = adj_mat[node_indices[u]][node_indices[w]]

        g = nx.DiGraph()
        g.add_nodes_from(new_V)
        for i in range(len(new_adj_mat)):
            for j in range(len(new_adj_mat[i])):
                if new_adj_mat[i][j] == 1:
                    g.add_edge(new_V[i], new_V[j])

        # Check if new graph has cycles
        try:
            list(nx.topological_sort(g))
        except nx.NetworkXUnfeasible:
            print(f"Warning: Reduced graph contains cycle, removing edge {new_V[i]}→{new_V[j]}")
            g.remove_edge(new_V[i], new_V[j])

    return g

def reduce_subgraph(g, treatment, outcome):
    g = reduce_dag(g, treatment, outcome)
    reduce_subgraph_nodes = list(g.nodes())
    return g, reduce_subgraph_nodes