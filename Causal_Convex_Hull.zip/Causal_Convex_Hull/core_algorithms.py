import networkx as nx
from collections import deque
from networkx.algorithms.flow import dinitz

######################### Proper Backdoor Graph (PBDG)  ###########################
def find_causal_nodes(G, A, Y):
    """
    Find all nodes on causal paths from treatment to outcome.

    Input:
        G: DAG
        A: The treatment variable
        Y: The outcome variable

    Output:
        all causal nodes from A to Y
    """
    # Find all descendants of the treatment node
    descendants_A = nx.descendants(G, A) | {A}

    # Find all ancestors of the outcome node
    ancestors_Y = nx.ancestors(G, Y) | {Y}

    # Causal nodes are the intersection of descendants of A and ancestors of Y, plus the Y
    cn = descendants_A & ancestors_Y

    return cn


def PBDG(G, A, Y):
    """
    Construct a Proper Backdoor Graph (PBDG) by removing direct A edges.

    Input:
        G: DAG
        A: The treatment variable
        Y: The outcome variable

    Output:
        G_pbd: The constructed Proper Backdoor Graph
    """
    # Create a copy of the original graph to modify
    G_pbd = G.copy()

    # Step 1: Find all causal nodes cn_G(A, Y)
    cn = find_causal_nodes(G, A, Y)

    # Step 2: Remove edges: {A → V | V ∈ cn_G(A, Y) \ {A}}
    for node in cn - {A}:
        if G_pbd.has_edge(A, node):
            G_pbd.remove_edge(A, node)

    return G_pbd


##########################Inducing Path Detection Algorithm(IPD)####################
def get_ancestors(G, nodes):
    """
    Finds all ancestors of a set of nodes in a DAG.

    Input:
        G: DAG
        nodes: The set of nodes

    Output:
        All ancestors
    """
    ancestors = set()
    queue = deque(nodes)

    while queue:
        node = queue.popleft()
        for parent in G.predecessors(node):
            if parent not in ancestors:
                ancestors.add(parent)
                queue.append(parent)

    return ancestors

def IPD(G, U, V, M, cache=None):
    """
    Check for the existence of an inducing path between two nodes in a DAG.

    Input:
       G : DAG
       U : Starting node of the path
       V : Ending node of the path
       M : Set of nodes that non-endpoint nodes must belong to
       cache: Optional result cache

    Output:
        True if inducing path exists, False otherwise
    """
    if cache is None:
        cache = {}

    cache_key = (U, V, frozenset(M))
    if cache_key in cache:
        return cache[cache_key]

    # Directly adjacent nodes cannot form an inducing path
    if G.has_edge(U, V) or G.has_edge(V, U):
        cache[cache_key] = False
        return False

    # Compute ancestor set and restrict search space
    ancestor_set = get_ancestors(G, {U, V})  #O(|V| + |E|)
    W = (M & ancestor_set) | {U, V}

    # Early termination if search space is too small
    if len(W) < 3:
        cache[cache_key] = False
        return False

    def get_neighbors(node):

        neighbors = []
        # Explore forward direction (successors)
        for succ in G.successors(node):
            if succ in W:
                neighbors.append(succ)
        # Explore backward direction (predecessors)
        for pred in G.predecessors(node):
            if pred in W:
                neighbors.append(pred)
        return neighbors

    # Initialize bidirectional BFS   #O(|V| + |E|)
    # Forward search: from U to V
    # Backward search: from V to U
    forward_visited = {U: None}  # Maps node -> parent node for path reconstruction
    backward_visited = {V: None}

    forward_queue = deque([U])
    backward_queue = deque([V])

    forward_level = {U: 0}  # Track distance from start node
    backward_level = {V: 0}

    meeting_node = None  # Node where forward and backward searches meet

    # Execute bidirectional BFS until paths meet or queues are exhausted
    while forward_queue and backward_queue:
        # Expand forward search frontier
        current_forward = forward_queue.popleft()

        for neighbor in get_neighbors(current_forward):
            if neighbor not in forward_visited:
                forward_visited[neighbor] = current_forward
                forward_level[neighbor] = forward_level[current_forward] + 1
                forward_queue.append(neighbor)

                # Check if this node has been reached by backward search
                if neighbor in backward_visited:
                    meeting_node = neighbor
                    break

        if meeting_node:
            break

        # Expand backward search frontier
        current_backward = backward_queue.popleft()

        for neighbor in get_neighbors(current_backward):
            if neighbor not in backward_visited:
                backward_visited[neighbor] = current_backward
                backward_level[neighbor] = backward_level[current_backward] + 1
                backward_queue.append(neighbor)

                # Check if this node has been reached by forward search
                if neighbor in forward_visited:
                    meeting_node = neighbor
                    break

        if meeting_node:
            break

    # No path exists if searches didn't meet
    if not meeting_node:
        cache[cache_key] = False
        return False

    def reconstruct_path(meet_node):

        # Reconstruct forward segment (u -> meet_node)
        forward_part = []
        node = meet_node
        while node is not None:
            forward_part.append(node)
            node = forward_visited.get(node)
        forward_part.reverse()  # Reverse to get correct order from u to meet_node

        # Reconstruct backward segment (meet_node -> v)
        backward_part = []
        node = backward_visited.get(meet_node)
        while node is not None:
            backward_part.append(node)
            node = backward_visited.get(node)

        # Combine segments to form complete path
        full_path = forward_part + backward_part
        return full_path

    def check_path_conditions(path):#O(|V|)

        # Path must have at least 3 nodes (u, intermediate, v)
        if len(path) < 3:
            return False

        # Check each intermediate node in the path
        for i in range(1, len(path) - 1):
            current = path[i]
            prev, nxt = path[i - 1], path[i + 1]

            # Determine if current node is a collider
            # A collider has edges pointing toward it from both neighbors
            is_collider = (G.has_edge(prev, current) and G.has_edge(nxt, current))

            if is_collider:
                # Colliders must be ancestors of {u, v}
                if current not in ancestor_set:
                    return False
            else:
                # Non-colliders must be in M
                if current not in M:
                    return False

        return True

    # Check the primary meeting path first
    candidate_path = reconstruct_path(meeting_node)

    if check_path_conditions(candidate_path):
        cache[cache_key] = True
        return True

    # If primary path fails, check alternative meeting points
    # This handles cases where multiple valid paths exist
    meeting_candidates = set(forward_visited.keys()) & set(backward_visited.keys())

    for alt_meeting in meeting_candidates:
        if alt_meeting == meeting_node:
            continue

        alt_path = reconstruct_path(alt_meeting)
        if check_path_conditions(alt_path):
            cache[cache_key] = True
            return True

    # No valid inducing path found
    cache[cache_key] = False
    return False

################## Sinking Causal Convex Hull Algorithm(SCCH)  #######################
def moral_graph(G, subgraph_nodes=None):
    """
    Input:
        G: DAG
        subgraph_nodes: Nodes to include in the subgraph.

    Output:
        The moral graph of the specified subgraph
    """

    # Ensure subgraph_nodes is a set for efficient membership checks
    if subgraph_nodes is None:
        subgraph_nodes = set(G.nodes())
    else:
        subgraph_nodes = set(subgraph_nodes)

    moral_g = nx.Graph()
    moral_g.add_nodes_from(subgraph_nodes)

    # Build the set of edges to add (avoids duplicate edges automatically)
    edges_to_add = set()

    # Step 1: Add all directed edges in the subgraph as undirected edges
    for u, v in G.edges():
        if u in subgraph_nodes and v in subgraph_nodes:
            edges_to_add.add((u, v))

    # Step 2: Add edges between all pairs of co-parents for each node in the subgraph
    for node in subgraph_nodes:
        # Get all parents of the current node that are in the subgraph
        parents = [p for p in G.predecessors(node) if p in subgraph_nodes]
        # Connect every pair of co-parents (avoid duplicate pairs with i < j)
        for i in range(len(parents)):
            for j in range(i + 1, len(parents)):
                edges_to_add.add((parents[i], parents[j]))

    moral_g.add_edges_from(edges_to_add)
    return moral_g

def find_min_vertex_cut_no_h(G, U, V, H, cache=None):
    """
    Finds the minimum vertex cut between U and V, excluding vertices already in H.

    Input:
        G: DAG
        U, V: Nodes between which an inducing path exists
        H: Current set of vertices (to exclude from result)
        cache: Cache for storing intermediate results

    Output:
        Minimum vertex cut vertices that are not already in H
    """
    if cache is None:
        cache = {}

    # Calculate ancestor set
    ancestor_key = (U, V)
    if ancestor_key not in cache:
        cache[ancestor_key] = get_ancestors(G, {U, V})|{U,V}
    ancestor_set = cache[ancestor_key]

    # No need to add vertices if ancestors are already in h
    if ancestor_set.issubset(H):
        return set()

    # Build moral graph
    moral_key = frozenset(ancestor_set)
    if moral_key not in cache:
        cache[moral_key] = moral_graph(G, ancestor_set)
    G_moral_anc = cache[moral_key]

    # Check connectivity
    if not nx.has_path(G_moral_anc, U, V):
        return set()

    # Find minimum vertex cut
    C_min = nx.minimum_node_cut(G_moral_anc, U, V, flow_func=dinitz)


    # Return vertices in the cut that are not already in h
    return C_min - H if C_min else set()


def SCCH(G, R):
    """
    Compute the Causal Convex Hull containing R.
    Input:
        G: DAG
        R: Initial set of nodes

    Output:
        The Causal Convex Hull G_{H} containing R and the vertex set H

    Time Complexity: O(|V|^{5}|E|)
    """
    H = R
    all_nodes = set(G.nodes())

    # Initialize the pairs of nodes to be checked
    Q = set()
    # Initialize queue with non-adjacent node pairs from  H
    nodes_list = sorted(H)
    for i in range(len(nodes_list)):
        for j in range(i + 1, len(nodes_list)):
            U,V = nodes_list[i],nodes_list[j]
            if not G.has_edge(U, V) and not G.has_edge(V, U):
                Q.add((min(U, V), max(U, V))) # Store pairs in standardized order


    C = set()  # Checked pairs (no need to check again)
    cache = {}

    while Q: #O(|V|)
        M = all_nodes - H
        pair_found = False

        # Check all pending node pairs
        for U, V in list(Q):
            if IPD(G, U, V, M, cache):
                Q.remove((U, V))
                C_min_noH = find_min_vertex_cut_no_h(G, U, V, H, cache)  # C_min_noH=C_min-h

                if C_min_noH:
                    H.update(C_min_noH)

                    # Add new node pairs to Q
                    for x in C_min_noH:
                        for y in H:
                            if x != y:
                                pair = (min(x, y), max(x, y))
                                # Add if not checked, not in queue, and not adjacent
                                if (pair not in C and pair not in Q and
                                        not G.has_edge(pair[0], pair[1]) and
                                        not G.has_edge(pair[1], pair[0])):
                                    Q.add(pair)

                    # Clear cache since H changed
                    cache.clear()
                    pair_found = True
                    break
                else:
                    C.add((U, V))  # Path exists but no new vertices needed
            else:
                Q.remove((U, V))
                C.add((U, V))

        # If no nodes to be added are found in this iteration, continue checking other pairs.
        if not pair_found:
            # All pairs in the current Q have been checked, and the while loop continues.
            continue

    return G.subgraph(H),H

############################### Two-Stage Causal Convex Hull Construction Algorithm ##################################
def TSCCHC(G, A, Y):
    """
     Input:
        G: DAG
        A: Treatment variable
        Y: Outcome variable

    Output:
        The convex subgraph G_{H*} and the vertex set H*

    Time Complexity: O(|V|^{5}|E|)
    """

    # Step 1: Construct Proper Back-Door Graph (PBDG)
    G_pbd = PBDG(G, A, Y) #O(|V| + |E|)

    # Step 2: Find all nodes on causal paths between A and Y
    R = find_causal_nodes(G, A, Y)  # O(|V| + |E|)


    # Step 3: Check for inducing paths in PBDG
    M = set(G.nodes()) - {A, Y}
    I = IPD(G_pbd, A, Y, M)  #O(|V| + |E|)

    if I:
        # Case 1: Inducing paths exist
        _,H = SCCH(G_pbd, {A, Y})  #O(|V|^{5}|E|)
        G_H_star,H_star = SCCH(G, H | R) #O(|V|^{5}|E|)
    else:
        # Case 2: No inducing paths
        G_H_star,H_star = SCCH(G, R) #O(|V|^{5}|E|)


    return G_H_star,sorted(H_star)





