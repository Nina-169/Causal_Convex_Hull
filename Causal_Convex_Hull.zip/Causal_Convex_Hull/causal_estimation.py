import warnings
import sys
import os

warnings.filterwarnings("ignore")
warnings.simplefilter("ignore")
sys.stderr = open(os.devnull, 'w')

import numpy as np
import random
from pgmpy.inference import VariableElimination
from pgmpy.factors.discrete import TabularCPD
from pgmpy.sampling import BayesianModelSampling
from pgmpy.models import BayesianNetwork
from pgmpy.estimators import MaximumLikelihoodEstimator



#######################################Compute the true ATE##################################################
def get_state_names(G):
    """
    Extract state names for all nodes in the Bayesian network.

    Args:
        G: Bayesian network model

    Returns:
        dict: Mapping from node names to their state names list
    """
    state_names = {}
    for node in G.nodes():
        cpd = G.get_cpds(node)

        if cpd is None:
            continue

        # Try multiple ways to extract state names
        if hasattr(cpd, 'state_names') and cpd.state_names:
            # Extract state names for this specific node
            if node in cpd.state_names:
                state_names[node] = list(cpd.state_names[node])
            else:
                # Fallback: check if state_names is a dict
                state_names[node] = [f"state_{i}" for i in range(cpd.variable_card)]
        else:
            # Create default state names
            state_names[node] = [f"state_{i}" for i in range(cpd.variable_card)]

    return state_names


def compute_intervention_means_from_model(G, treatment, outcome, treatment_idx, outcome_idx):
    """
    Compute intervention means from a Bayesian network model.
    Works for both true model and learned model.

    Args:
        G: Bayesian network model (can be true model or learned model)
        treatment: Treatment variable
        outcome: Outcome variable
        treatment_idx: Treatment value index
        outcome_idx: Outcome value index

    Returns:
        float: Probability of outcome at outcome_idx after intervention
    """
    # Create a copy of the model to avoid modifying the original
    G_copy = G.copy()

    # Get state names from the model
    state_names = get_state_names(G_copy)

    # Get original CPD of treatment variable
    cpd_treatment = G_copy.get_cpds(treatment)
    if cpd_treatment is None:
        raise ValueError(f"No CPD found for treatment variable '{treatment}'")

    treatment_card = cpd_treatment.variable_card

    # Validate treatment index
    if treatment_idx >= treatment_card:
        raise ValueError(f"Treatment index {treatment_idx} out of range for {treatment} (cardinality={treatment_card})")

    # Extract parent information
    evidence_vars = []
    if hasattr(cpd_treatment, 'evidence'):
        evidence_vars = list(cpd_treatment.evidence)
    elif hasattr(cpd_treatment, 'variables'):
        evidence_vars = list(cpd_treatment.variables[1:]) if len(cpd_treatment.variables) > 1 else []

    # Retrieve the cardinality of the evidence variables
    evidence_card = []
    if hasattr(cpd_treatment, 'evidence_card'):
        evidence_card = list(cpd_treatment.evidence_card)
    elif evidence_vars and hasattr(cpd_treatment, 'cardinality'):
        evidence_card = list(cpd_treatment.cardinality[1:]) if len(cpd_treatment.cardinality) > 1 else []

    # Create intervened CPD (fix treatment to specified value)
    if len(evidence_vars) == 0:
        # No parents
        values = np.zeros((treatment_card, 1))
        values[treatment_idx, 0] = 1.0
    else:
        # Has parents
        num_parent_combinations = int(np.prod(evidence_card))
        values = np.zeros((treatment_card, num_parent_combinations))
        values[treatment_idx, :] = 1.0

    # Prepare state names for parent variables
    complete_state_names = {treatment: state_names.get(treatment,
                                                       [f"state_{i}" for i in range(treatment_card)])}

    for ev in evidence_vars:
        if ev in state_names:
            complete_state_names[ev] = state_names[ev]
        else:
            # Create default state names if not available
            if hasattr(cpd_treatment, 'cardinality') and ev in cpd_treatment.variables:
                idx = cpd_treatment.variables.index(ev)
                ev_card = cpd_treatment.cardinality[idx]
            else:
                ev_card = 2  # Default binary
            complete_state_names[ev] = [f"state_{i}" for i in range(ev_card)]

    # Create new CPD for intervened variable
    new_cpd = TabularCPD(
        variable=treatment,
        variable_card=treatment_card,
        values=values,
        evidence=evidence_vars if evidence_vars else None,
        evidence_card=evidence_card if evidence_vars else None,
        state_names=complete_state_names
    )

    # Replace the original CPD with the intervened one
    G_copy.remove_cpds(treatment)
    G_copy.add_cpds(new_cpd)

    # Perform inference
    infer = VariableElimination(G_copy)
    result = infer.query(variables=[outcome], show_progress=False)

    # Validate outcome index
    if outcome_idx >= len(result.values):
        raise ValueError(f"Outcome index {outcome_idx} out of range for outcome variable '{outcome}' "
                         f"(cardinality={len(result.values)})")

    # Extract probability for the specified outcome state
    return float(result.values[outcome_idx])


def compute_true_ATE(G, treatment, outcome, treatment_pos_idx, treatment_neg_idx, outcome_pos_idx):
    """
    Compute true Average Treatment Effect (ATE) from the causal model.

    Args:
        G: Bayesian network model
        treatment: Treatment variable
        outcome: Outcome variable
        treatment_pos_idx: Index of positive treatment state
        treatment_neg_idx: Index of negative treatment state
        outcome_pos_idx: Index of positive outcome state

    Returns:
        tuple: (ATE, P(Y=outcome_pos_idx|do(A=treatment_pos_idx)),
                P(Y=outcome_pos_idx|do(A=treatment_neg_idx)))
    """
    # Get state names
    state_names = get_state_names(G)
    treatment_states = state_names[treatment]
    outcome_states = state_names[outcome]

    # Verify whether the treatment and outcome variables are binary
    if len(treatment_states) != 2:
        print(f"Warning: Treatment variable {treatment} has {len(treatment_states)} states, not binary")
    if len(outcome_states) != 2:
        print(f"Warning: Outcome variable {outcome} has {len(outcome_states)} states, not binary")

    # Validate indices
    for idx, var_name, states in [
        (treatment_pos_idx, "treatment positive", treatment_states),
        (treatment_neg_idx, "treatment negative", treatment_states),
        (outcome_pos_idx, "outcome positive", outcome_states)
    ]:
        if idx >= len(states):
            raise ValueError(
                f"{var_name} index {idx} out of range for variable with states: {states}"
            )

    # Compute intervention means from model
    true_psi1 = compute_intervention_means_from_model(G, treatment, outcome, treatment_pos_idx, outcome_pos_idx)
    true_psi0 = compute_intervention_means_from_model(G, treatment, outcome, treatment_neg_idx, outcome_pos_idx)

    # Compute ATE
    true_ATE = true_psi1 - true_psi0

    return true_ATE, true_psi1, true_psi0

##################### Calculate the average estimated ATE and its evaluation metrics###########################
def generate_data(G, n, treatment, outcome, seed):
    """
    Generate synthetic data from a Bayesian network model.

    Args:
        G: Bayesian network model
        n: Number of samples to generate
        treatment: Treatment variable
        outcome: Outcome variable
        seed: Random seed for reproducibility

    Returns:
        pandas.DataFrame: Generated dataset
    """

    # Set random seeds for reproducibility
    np.random.seed(seed)
    random.seed(seed)

    # Validate variables exist in the network
    for var in [treatment, outcome]:
        if var not in G.nodes():
            raise ValueError(f"Variable {var} not found in the network")

    # Generate data (preserving original state names)
    sampler = BayesianModelSampling(G)
    data = sampler.forward_sample(size=n, show_progress=False)

    return data


def learn_model_from_data(data, G_structure):
    """
    Learn model parameters from data using a given structure.

    Args:
        data: Observational data
        G_structure: BayesianNetwork with structure only (no CPDs)

    Returns:
        BayesianNetwork: Model with learned CPDs from data
        dict: State mappings for all variables
    """
    # Convert data to numerical indices
    data_numeric = data.copy()
    state_mappings = {}

    for col in data_numeric.columns:
        if col not in G_structure.nodes():
            continue

        unique_states = sorted(data_numeric[col].dropna().unique())
        mapping = {state: idx for idx, state in enumerate(unique_states)}
        state_mappings[col] = {
            'states': unique_states,
            'mapping': mapping,
            'reverse_mapping': {idx: state for state, idx in mapping.items()}
        }
        data_numeric[col] = data_numeric[col].map(mapping)

    # Keep only relevant columns
    columns_to_keep = [col for col in data_numeric.columns if col in G_structure.nodes()]
    data_numeric = data_numeric[columns_to_keep].copy()

    # Fit model using Maximum Likelihood Estimation
    estimator = MaximumLikelihoodEstimator(G_structure, data_numeric)

    # Estimate CPDs for all nodes
    estimated_cpds = []
    for node in G_structure.nodes():
        cpd = estimator.estimate_cpd(node)
        estimated_cpds.append(cpd)

    # Create a new model with learned CPDs
    learned_model = BayesianNetwork(G_structure.edges())
    learned_model.add_cpds(*estimated_cpds)

    # Add the correct state names to the learned model
    for cpd in learned_model.get_cpds():
        if hasattr(cpd, 'state_names'):
            for var in cpd.variables:
                if var in state_mappings:
                    cpd.state_names[var] = state_mappings[var]['states']

    return learned_model, state_mappings

def compute_ATE_from_data(data, G, treatment, outcome, treatment_pos_idx, treatment_neg_idx, outcome_pos_idx):
    """
    Compute ATE from data using the causal structure from G.

    Args:
        data: Observational data
        G: Full Bayesian network (we only use its structure, not its CPDs)
        treatment: Treatment variable
        outcome: Outcome variable
        treatment_pos_idx: Index of positive treatment state
        treatment_neg_idx: Index of negative treatment state
        outcome_pos_idx: Index of positive outcome state

    Returns:
        float: Estimated P(outcome | do(treatment)) from data
    """
    # Extract structure from full model
    G_structure = BayesianNetwork(G.edges())

    # Learn model from data
    learned_model, _ = learn_model_from_data(data, G_structure)

    # Compute intervention effect using the learned model
    est_psi1 = compute_intervention_means_from_model(learned_model,treatment, outcome, treatment_pos_idx, outcome_pos_idx)
    est_psi0 = compute_intervention_means_from_model(learned_model,treatment, outcome, treatment_neg_idx, outcome_pos_idx)
    est_ATE = est_psi1 - est_psi0

    return est_ATE

def compute_average_est_ATE_statistics(G, treatment, outcome, treatment_pos_idx, treatment_neg_idx, outcome_pos_idx,
                                       n, m,true_ATE=None, G_R=None, R=None):
    """
    Compute average ATE estimation statistics.

    Args:
        G: Full Bayesian network model
        treatment: Treatment variable
        outcome: Outcome variable
        treatment_pos_idx: Index of positive treatment state
        treatment_neg_idx: Index of negative treatment state
        outcome_pos_idx: Index of positive outcome state
        n: Sample size per experiment
        m: Number of experiments
        true_ATE: True ATE value (optional)
        G_R: Reduced graph model (optional)
        R: Set of nodes in reduced graph (optional)

    Returns:
        dict: Statistics including average estimated ATE, std, bias, RMSE
    """
    est_ATE_values = []
    detailed_results = []

    for i in range(m):
        try:
            # Generate synthetic observational data with different random seeds
            current_seed = 42 + i * 100  # Assign distinct random seed for each iteration

            data = generate_data(G, n, treatment, outcome, seed=current_seed)

            if G_R is not None and R is not None:
                # Use reduced graph: extract sub-dataset
                sub_data = data[list(R)].copy()

                # Compute intervention means from sub_data using reduced graph structure
                est_ATE = compute_ATE_from_data(
                    sub_data, G_R, treatment, outcome, treatment_pos_idx, treatment_neg_idx, outcome_pos_idx)
            else:
                # Use full graph
                est_ATE = compute_ATE_from_data(
                    data, G, treatment, outcome, treatment_pos_idx, treatment_neg_idx, outcome_pos_idx)


            est_ATE_values.append(est_ATE)

            detailed_results.append({
                'experiment': i + 1,
                'seed': current_seed,
                'est_ATE': est_ATE,
            })

        except Exception as e:
            print(f"Experiment {i + 1} failed: {str(e)[:100]}")
            continue

    # Calculate statistics after all experiments
    est_ATE_array = np.array(est_ATE_values)

    stats = {
        'avg_est_ATE': float(np.mean(est_ATE_array)),
        'std_est_ATE': float(np.std(est_ATE_array, ddof=1)),
    }

    # Calculate additional metrics if true ATE is provided
    if true_ATE is not None:
        stats.update({
            'true_ATE': float(true_ATE),
            'bias': float(np.mean(est_ATE_array) - true_ATE),
            'RMSE': float(np.sqrt(np.mean((est_ATE_array - true_ATE) ** 2))),
        })

    return stats

def compute_average_est_ATE_realdata(data, G, treatment, outcome,
                             treatment_pos_idx, treatment_neg_idx, outcome_pos_idx,
                             B=500,seed=42):
    """
    Estimating the ATE and its uncertainty using the Bootstrap method.

    Args:
        data: complete observed dataset(pandas DataFrame)
        G: causal diagram structure (BayesianNetwork)
        treatment: Treatment variable
        outcome: Outcome variable
        treatment_pos_idx: Index of positive treatment state
        treatment_neg_idx: Index of negative treatment state
        outcome_pos_idx: Index of positive outcome state
        B: Number of Bootstrap resamples

    Returns:
        Dictionary containing ATE point estimate,
              bootstrap mean, standard error, and confidence interval.
    """

    np.random.seed(seed)
    random.seed(seed)

    n = len(data)
    bootstrap_ATEs = []


    # 1. Point estimate based on the full data
    ATE_full = compute_ATE_from_data(
        data, G, treatment, outcome,
        treatment_pos_idx, treatment_neg_idx, outcome_pos_idx
    )

    # 2. Bootstrap resampling
    for b in range(B):
        try:
            # Drawing Bootstrap samples with replacement
            bootstrap_indices = np.random.choice(n, size=n, replace=True)
            bootstrap_sample = data.iloc[bootstrap_indices].reset_index(drop=True)

            # Calculating the ATE on the Bootstrap sample
            est_ATE = compute_ATE_from_data(
                bootstrap_sample, G, treatment, outcome,
                treatment_pos_idx, treatment_neg_idx, outcome_pos_idx
            )
            bootstrap_ATEs.append(est_ATE)

        except Exception as e:
            print(f"Bootstrap iteration {b + 1} failed: {e}")
            continue

    # 3. Calculating the Bootstrap statistics
    bootstrap_ATEs = np.array(bootstrap_ATEs)

    results = {
        'ATE_full': ATE_full,
        'ATE_boot_mean': float(np.mean(bootstrap_ATEs)),
        'ATE_boot_std': float(np.std(bootstrap_ATEs, ddof=1)),
        'ATE_boot_CI_lower': float(np.percentile(bootstrap_ATEs, 2.5)),
        'ATE_boot_CI_upper': float(np.percentile(bootstrap_ATEs, 97.5)),
        'B': B,
        'n': n,
    }

    return results


