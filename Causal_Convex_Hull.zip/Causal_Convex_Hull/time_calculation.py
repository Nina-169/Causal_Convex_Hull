import time

def calculate_average_wall_clock_time(func, args, num_runs, warmup):

    for _ in range(warmup):
        func(*args)

    total_runtime = 0
    for _ in range(num_runs):
        start_time = time.time()
        func(*args)
        end_time = time.time()

        total_runtime += (end_time - start_time)

    average_runtime = total_runtime / num_runs
    return round(average_runtime, 4)